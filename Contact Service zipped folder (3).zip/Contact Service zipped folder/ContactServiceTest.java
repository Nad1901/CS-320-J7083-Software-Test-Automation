import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class ContactServiceTest {
    @Test
    public void testAddDeleteContact() {
        ContactService contactService = new ContactService();
        Contact contact = new Contact("1", "John", "Doe", "1234567890", "123 Main St");

        contactService.addContact(contact);
        assertNotNull(contactService.getContact("1"));

        contactService.deleteContact("1");
        assertNull(contactService.getContact("1"));
    }

    @Test
    public void testUpdateContact() {
        ContactService contactService = new ContactService();
        Contact contact = new Contact("1", "John", "Doe", "1234567890", "123 Main St");

        contactService.addContact(contact);
        assertEquals("John", contactService.getContact("1").getFirstName());

        contactService.updateContactField("1", "firstName", "Jane");
        assertEquals("Jane", contactService.getContact("1").getFirstName());
    }
}
